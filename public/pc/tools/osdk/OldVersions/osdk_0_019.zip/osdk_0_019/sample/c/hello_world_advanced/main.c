//
// TEST_4
//
// This is a "HELLO WORLD" sample using
// an assembly code routine to display
// the message
//


// Declare the assembly code function
void AdvancedPrint(char x_pos,char y_pos,const char *ptr_message);


void main()
{
	AdvancedPrint(2,1,"Hello World !");
	AdvancedPrint(3,2,"Hello World !");
	AdvancedPrint(4,3,"Hello World !");
}
