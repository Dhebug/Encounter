//
// This program simply display a compressed picture on the hires screen
//

#include <lib.h>

extern unsigned char LabelPicture[];

void main()
{
	hires();
	file_unpack((unsigned char*)0xa000,LabelPicture);
}

